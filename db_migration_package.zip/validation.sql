-- Check in MySQL:
SELECT 'users' AS table_name, COUNT(*) AS row_count FROM users
UNION
SELECT 'orders', COUNT(*) FROM orders;

-- Check in PostgreSQL:
SELECT 'users' AS table_name, COUNT(*) AS row_count FROM users
UNION
SELECT 'orders', COUNT(*) FROM orders;